package FairMatic.Services;

public interface LoadData {
    void loadData(String path);
}
